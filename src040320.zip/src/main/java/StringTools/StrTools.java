package StringTools;

public class StrTools {
	static final String operatorChar = "-+*/=<>:";
	static final String spaceChar = " \n\r\t";
	static final String allowVarChar = "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890_.";
	static final String allowFirstChar = "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm_";

	public boolean IsVarName(String s) {
		if(s.isEmpty()) return false;
		char[] chArr = s.toCharArray();
		if(allowFirstChar.indexOf(chArr[0]) < 0) return false;
		for(int i = 1; i < chArr.length; i++) if(allowVarChar.indexOf(chArr[i]) < 0) return false;
		return true;
	}
}