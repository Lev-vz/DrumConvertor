package XMLTools;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/*@author lev*/
public class nodeXML implements Comparable<nodeXML> {
    String name;
    Map<String, String> attribut;
    boolean singl;
    ArrayList<nodeXML> nodeList;
    String content = "";
    String cdata;
    
    public nodeXML(String Name, boolean Singl){
        name = Name;
        singl = Singl;
        nodeList = new ArrayList<>();
        attribut = new HashMap<String, String>();
    }
    public nodeXML(String Name, boolean Singl, ArrayList<String[]> attrList){
        name = Name;
        singl = Singl;
        nodeList = new ArrayList<>();
        attribut = new HashMap<String, String>();
        for(String[] al: attrList)attribut.put(al[0], al[1]);
    }
    
    int indexOf(String nx){
        for(int i=0; i < nodeList.size(); i++) if(nx == nodeList.get(i).name) return i;
        return -1;
    }
    nodeXML getNode(String nodeName) {
        for(int i=0; i < nodeList.size(); i++) if(nodeName.equals(nodeList.get(i).name)) return nodeList.get(i);
        return null;
    }
    nodeXML getNode(String nodeName, String attrName) {
        for(int i=0; i < nodeList.size(); i++) 
            if(nodeName.equals(nodeList.get(i).name) && 
               attrName.equals(nodeList.get(i).attribut.get("Name"))) return nodeList.get(i);
        return null;
    }
    @Override
    public int compareTo(nodeXML nx) {
        return this.name.compareTo(nx.name);
    }
    
}
