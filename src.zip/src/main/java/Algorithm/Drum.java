package Algorithm;

public class Drum {
    String name;
    String rusName;
    int qStep;
    int qTimer;
    
}
