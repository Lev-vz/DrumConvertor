package main;

import Algorithm.formula;
import StringTools.StrTools;
import fileTools.FileManager;
import fileTools.svgTools;
import globalData.globVar;

import java.io.IOException;

public class main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		globVar.linSep = System.getProperty("line.separator");
		globVar.myDir = System.getProperty("user.dir"); //user.dir
		//globVar.desDir = globVar.myDir+"\\Design";
		globVar.fm = new FileManager();
		globVar.st = new StrTools();
                //formula f2 = new formula("uuu:=(qqq[  0 ] OR (ww.w AND (1eee or .rrr)) : _tt,t ++ (yy/ff*gg^2))>=(16.5 % 3)");
                formula f2 = new formula("DGO.Sirena_ON:= not(BBB and EEE or CCC ) and not DDD");
                System.out.println(f2.getSelf());
               
                int h = f2.CalcH();
                int w = f2.CalcW();
                System.out.println("H = " + h + ", W = " + w);
                globVar.fm.createFile2write(globVar.myDir, "drum1.svg");
                globVar.fm.wr(svgTools.getSvgTitleA4());
                f2.drawSelf(w, 10, h);
                globVar.fm.wr(svgTools.getSvgEnd());
                globVar.fm.wrStream.close();
                
	}

}

/*
		//System.out.println(uuid);// + globVar.linSep);
		int x = globVar.fm.openFile4read(globVar.myDir, "drum1.st");
                if(x != 0) System.out.println(Integer.toString(x));
                else {
                    globVar.fm.createFile2write(globVar.myDir, "drum1.swg");
                    while(!globVar.EOF) {
                            String buf = globVar.fm.rd();
                            globVar.fm.wr(buf + globVar.linSep);
                            //System.out.println("[" + buf +"]" + globVar.EOF); //------------ контрольный вывод
                    }
                    globVar.fm.wrStream.close();
                    globVar.fm.rdStream.close();
                }
*/
