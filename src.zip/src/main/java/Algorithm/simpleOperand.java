package Algorithm;

import fileTools.svgTools;
import globalData.globVar;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*@author lev*/
public class simpleOperand extends operand{
    String o;
    public simpleOperand(String O, String op) {o = O; opa = op;}
    @Override
    public String getSelf(){
        return o + "{" + opa + "}";
    }
    public void setSelf(String O){
        o = O;
    }
    @Override
    public int CalcW() {
        return (o.length()+2) * globVar.simbolWidth;
    }
    @Override
    public int CalcH() {
        return globVar.simbolHeight;
    }

    @Override
    public void drawSelf(int x, int y, int h) {
            int w = (o.length() + 3) * globVar.simbolWidth;
        try {
            globVar.fm.wr(svgTools.drawSvgTextRect((x-w-10),(y+h/2-globVar.simbolHeight/2), w, globVar.simbolHeight,o,o));
        } catch (IOException ex) {
            Logger.getLogger(simpleOperand.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public formula getFormula() {
        return null;
    }
}
